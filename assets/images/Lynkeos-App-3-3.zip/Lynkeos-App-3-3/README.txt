Please read the license file.

A tutorial and the comprehensive help is available in the application.

This application should run on Intel MacOS X 10.7 or more.

WARNING: If you have previously installed a version earlier than v3.2 of the LynkeosCore framework in Library/Frameworks in your startup disk or home folder : delete this framework, because its presence, in an older version, can affect plugins loading and make the application unstable.

Copyrights:
Lynkeos, Copyright � 2003-2019 J-E. Lamiaud.
http://lynkeos.sourceforge.net/

Italian localization, Copyright � 2004-2005 Diego Meozzi.
Spanish localization, Copyright � 2005-2019 Laurence Bourcier Huet and Jean-Etienne Lamiaud

FFTW3, Copyright � 2003,2007-14 Matteo Frigo, Copyright � 2003,2007-14 Massachusetts Institute of Technology.

Libtiff, Copyright � 1988-1997 Sam Leffler, Copyright � 1991-1997 Silicon Graphics, Inc.
http://www.remotesensing.org/libtiff/

CFITSIO, Copyright � (Unpublished--all rights reserved under the copyright laws of the United States), U.S. Government as represented by the Administrator of the National Aeronautics and Space Administration.
http://www.fftw.org

DCRAW, Copyright � 1997-2018 by Dave Coffin, dcoffin a cybercom o net.
http://www.cybercom.net/~dcoffin/dcraw/

FFmpeg Copyright � 2001-2018 The ffmpeg project, refer to source code for (many) other copyrights.

SMDoubleSlider Copyright � 2003-2008, Snowmint Creative Solutions LLC http://www.snowmintcs.com/ All rights reserved.

History:
November 22, 2019: V3.3 release
Fix of plugins help opening
Fix of image saving right after document opening
Optimization of inter-threads communication
Update of Eclipse chaser plugins with the latest SDK

October 27, 2019: V3.2 release
Fix of a huge memory leak in reading RAW image files
Speedup of large images display (first part)
Fix of several multi-core issues (in interpolation and wavelet processing)
Fix of plugin initialisation issue in Catalina (OS X 10.15)

December 15, 2018: V3.1 release
Some fixes for the Cocoa reader, and fallback to FFMpeg for all QuickTime movies
Adaptation to high resolution display
SER movie format reader (experimental)

September 29, 2018: V3.0 release
Multi points alignment, with correction of rotation and scaling
Optimization of RAW files opening, with a progress pane
Update with latest versions of the libraries FFTW, CFITSIO, FFMPEG and TIFF

September 13, 2014: V2.10 release
Correction of RAW file opening failure (bug #74)
Workaround to open Canon DSLRs movies (bug #75)
Correction of the links to the Wiki inside the help (bug #79)

March 1, 2014: V2.9 release
New optimized processing of RAW format dark frames.
Correction of bad image refresh since OS X 10.8 (bug #73)
Correction of bugs in minimum, maximum and sigma clip stacking (bugs #57 and #70)

January 5, 2014: V2.8 release
Correction of a crash upon launch on OS X 10.9 Maverick (bug #72)
Correction of a crash when reverting to the "list" display after stacking, apparently also on OS X 10.9 (bug #71)
Correction to prevent a crash when stacking some dark frames (bug #59)

September 30, 2013: V2.7 release
Correction of a crash when using dark frames or flat fields (bug #67)
Workaround to open some kind of "mov" files (bug #68)
Correction of mouse selection in analysis and stack tools (bug #69)

August 13, 2013: V2.6a release
Static link with libtiff (bug #66 which forbid application launching on a regular OS X)

August 10, 2013: V2.6 release
Adaptation to OS X 10.8 (#58, #64)
New analysis algorithm, giving better results (#61)
More robust selection notification scheme, to avoid crash on infinite loop (#56)
Search square size is no more constrained to power of two (3440550)
FITS, MPEG and AVI file formats are now supported without additional packages.
The file format of V0 and V1 is no longer supported.

April 3, 2011: V2.5 release
Add of stacking variants "sigma clip" and "extrema" (2271899)
Add of RAW preference for automatic image rotation, or not.
Fix of plugins help display under OS X 10.6 (3268012)

December 18, 2008: V2.4 release
Correction of TIFF display on Intel (2127078)
Support for floating point TIFF (2216462),
Add of a process toggling on/off in the process stack window (2248076),
Implementation of a cache for image processing,
Refactoring of process chaining,
Fix of a bug in display when switching to/from calibration frames,
Better handling of exceptions in threads,
Fix of compatibility in reading files older than V2.3,
Access to the process window through the "window" menu,
Optimization of images refresh,
Access to plugins help,
Independent zoom factor for list and result modes.

September 28, 2008: V2.3 release
Add of the European Southern Observatory algorithm to the wavelet tool,
Parallelization (for multiproc/multicore) and vectorization (for Altivec/SSE) on most of the image processes,
Correction of TIFF files reading on Intel (2127078),
Fix of a memory leak at document closing (1975332),
Correction of a crash when saving an unprocessed image from a list (1928841),
Creation of a LynkeosCore framework to allow external processing plugin developement,
Correction of a crash when an exception is raised in a processing thread,
Delete RAW temporary files at application end,
Detect missing RAW files at document opening,
Add of a RAW conversion preference pane,
Fix of column sizes saving in the document,
Delete of useless "red" level and contrast line for monochrome images,
It is now possible to tweak the levels and contrast of an image in a list,
Fix of bad min and max image pixels values after some operations,
Fix of a bad read of quality threshold in pre V2 document files.

May 1, 2008: V2.2 release
Correction of  a crash upon some switching to list mode (1928672),
Correction of an endianness issue in RAW reader, which prevented its use on Intel architectures (1925582),
Correction of a missing refresh in the stacking tool (1885959),
Add of image updates in the process stack (1885960),
Correction of an issue with wavelet levels display after document load (1885958),
Correction of the impossibility to save an image from a list (1928841),
Add of a tool to correct the chromatic dispersion (1096730),
Add of scrollers to the alert panels (1067012),
URLs are now saved as relative to the document, which allows to move the images and movies with the document to another folder, or burn them on a CD (1929412),
Add of black, white and gamma setting for each color plane.

March 23, 2008: V2.1 release
Correction of  a stacking issue which made the application crash on some configurations (1901691),
Correction of the image updating during process (1922938),
Update of the RAW file types (1898526),
Watch cursor management correction (1210430),
Correction of some memory leaks,
Implementation of a cache for movie images which greatly speeds up image updating,
Grayscale Quicktime movies are no more read as RGB (which now allows to save the result as FITS).

February 3, 2008: V2.0 release
Correction of FITS saving in V2.0 (1869681),
Correction of some crashes of the developer release (1864269, 1860646, 1860644),
Correction of the creation of image processings inside the process stack window (1862762),
Correction of window closing while processing (1114333),
Implementation of an optional protection against spurious alignment (998921),
Correction of the "revert" function (1066998).

December 27, 2007: V2.0-dev release
	Developer release to evaluate the version 2.0 and report bugs.
Refactoring of application code,
Plug-in architecture for image processing,
Add of wavelet filter and Lucy-Richardson deconvolution.

September 3, 2006: V1.4 release
AVI and MPEG formats support, thanks to the FFmpeg library,
Fix of the launching on G4 (1536026),
Some more fixes of image scrambling in plugins  (1535076),
Fix of a RAW plugin loading problem (1539190),
Add of a warning window if the stacking is started without the calibration images being themselves stacked (1207360),
Reorganization of the "About" window (1067014),
Re-factoring, corrections and optimization of the stacking routine.

Aug 7, 2006: V1.3-UB release
Application and plugins recompiled as "Universal binaries",
Spanish localization by Laurence Bourcier-Huet,
Fix of processed image scrambling (1535076).

May 29, 2005: V1.3 release
Plugin architecture for image/movie file formats reading and saving,
Full resolution and monochrome TIFF images read (1069798),
Image saving into 8 or 16 bits TIFF,
Monochrome images/movies processing,
LRGB addition when combining RGB and monochrome images,
FITS image file format support for reading and saving (needs CFITSIO shared library to be installed) (1100700),
Digital cameras (most brands) RAW image file format support for (slow) reading,
Logarithmic scale for radius sliders in processing tab (1207372),
Fix a crash when analyzing on a biprocessor (1207368),
Improved automatic scrolling in the image frame (1207375),
Menu accessibility fix (1067002).

February 6, 2005: V1.2 release
Files can now be added by drag and drop (1067016),
Use of FFTW3 (Fastest Fourier Transform in the West version 3), for alignment, power spectrum analysis and processing. It is 1.4x faster on alignment and from 1.4x to 90x faster on processing!
Multiprocessor optimizations (1069795),
Some more optimizations (the overall improvement over v1.1 is ~3x on align/analysis/stack and up to ~100x on processing, for a G5 bipro),
Fixed a crash when aligning long sequences (1090624),
Fixed a big memory leak in alignment code (1095271),
Fixed a flip of the crop rectangle when dragging (1067003),
Fixed the display of the list frame alternating background (1067008),
Fixed a numeric error in entropy calculation (1111778),
The bundle identifier is now "net.sourceforge.lynkeos".

December 17, 2004: V1.1 delivery
option to stack monochrome flat fields (1068329),
new, more effective, analysis method based on image entropy (1066984),
take into account the image brightness in the power spectrum analysis (1066984),
sleep mode is now prevented during alignment, analysis and stacking (1069793),
fixed a problem when adding a "bad movie" (1066983),
fixed a crash when stacking with a large crop rectangle (1086655),
fixed a crash when adding many files at once (1066992),
fixed a memory leak in movie code (1072854),
crop rectangle is no more resizable in flat field or dark frame mode (1066997).

November 4, 2004: V1.0 delivery
Added support for dark frames and flat fields images,
Optimization of the alignment process (2 times faster),
Fixed the discard of saved black and white levels,
Fixed a "return to English" bug for non english localizations,
Added undo for add and delete in the list (not stable yet),
Added HeaderDoc (with support for Doxygen) document generation comments in the code.

July 29, 2004 : V0.4 delivery
Fixed crashes on alignment or analyze when no square is defined,
Fixed the impossibility to delete a movie.

July 22, 2004 : V0.3 delivery
Released in SourceForge,
Fixed the loss of the left and right arrow keys actions,
Fixed the crop rectangle disapearance on stacking,
Fixed a lack of update of the processed image after stacking.
Fixed the processed image "scrambling" when the crop rectangle is changed.
Fixed another case of processed image "scrambling" in one margin when the crop rectangle is near one side.
Fixed some invalid black and white levels.
Speed optimisation when no post processing is needed.

July 10, 2004 : Delivery of V0.2
Migration to Xcode
Searchable help thanks to the help index.
Fixed the need of re-stacking when opening a saved work.
Some actions did not marked the document as edited, it is now fixed.
Fixed the size at NSImage creation (although it had no visible effect).

June 29, 2004 : Initial delivery (v0.1)